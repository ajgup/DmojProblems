﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
namespace DMOJPassOrFail
{
    class Program
    {
        static void Main(string[] args)
        {
            //StreamReader sr = new StreamReader("Input.txt");
            bool Continue = true;
            int NumPass = 0;
            string[] StrWeight = Console.ReadLine().Split(' ');
            while (Continue == true)
            {
                
                double[] Weighting = new double[StrWeight.Length];
                int NumStudents = int.Parse(Console.ReadLine());
                for (int i = 0; i < StrWeight.Length; i++)
                {
                    Weighting[i] = double.Parse(StrWeight[i]);
                }
                double Percent = 0;
                for (int x = 0; x < NumStudents; x++)
                {
                    string[] Marks = Console.ReadLine().Split(' ');
                    double[] StudentMark = new double[Marks.Length];
                    for (int i = 0; i < StrWeight.Length; i++)
                    {
                        StudentMark[i] = double.Parse(Marks[i]);
                    }
                    for (int i = 0; i < Weighting.Length; i++)
                    {
                        Percent += (Weighting[i] / 100) * StudentMark[i];
                    }
                    if (Percent >= 50)
                    {
                        NumPass++;
                    }
                    Percent = 0;
                }

                Console.WriteLine(NumPass);
                NumPass = 0;
                try
                {
                    StrWeight = Console.ReadLine().Split(' ');                    
                }
                catch
                {
                    Continue = false;
                }
               
            }
            Console.ReadKey();
        }
    }
}
