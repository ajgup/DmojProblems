﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CCC_i_speak_txt
{
    class Program
    {
        static void Main(string[] args)
        {
            string input = "";
            do
            {
                input = Console.ReadLine();
                if (input == "CU")
                {
                    Console.WriteLine("see you");
                }
                else if (input == ":-)")
                {
                    Console.WriteLine("I'm happy");
                }
                else if (input == ":-(")
                {
                    Console.WriteLine("I'm unhappy");
                }
                else if (input == ";-)")
                {
                    Console.WriteLine("wink");
                }
                else if (input == ":-P")
                {
                    Console.WriteLine("stick out my tongue");
                }
                else if (input == "(<span>.</span><span>.</span>)")
                {
                    Console.WriteLine("sleepy");
                }
                else if (input == "TA")
                {
                    Console.WriteLine("totally awesome");
                }
                else if (input == "CCC")
                {
                    Console.WriteLine("Canadian Computing Competition");
                }
                else if (input == "CUZ")
                {
                    Console.WriteLine("because");
                }
                else if (input == "TY")
                {
                    Console.WriteLine("thank-you");
                }
                else if (input == "YW")
                {
                    Console.WriteLine("you're welcome");
                }
                else if (input == "TTYL")
                {
                    Console.WriteLine("talk to you later");
                }
                else
                {
                    Console.WriteLine(input);
                }
            } while (input != "TTYL");
        }
    }
}
