﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DMOPC18P1
{
    class Program
    {
        static void Main(string[] args)
        {
            int[] nums = new int[3];
            bool sorted = true;
            nums[0] = int.Parse(Console.ReadLine());
            nums[1] = int.Parse(Console.ReadLine());
            nums[2] = int.Parse(Console.ReadLine());
            int[] oldnums = new int[3];
            oldnums[0] = nums[0];
            oldnums[1] = nums[1];
            oldnums[2] = nums[2];
            Array.Sort(nums);
            for (int i = 0; i < 3; i++)
            {
                if (oldnums[i] != nums[i])
                {
                    Console.WriteLine("Try again!");
                    sorted = false;
                    break;  
                }
            }
            if (sorted)
            {
                Console.WriteLine("Good job!");
            }
            Console.ReadLine();
        }
    }
}
