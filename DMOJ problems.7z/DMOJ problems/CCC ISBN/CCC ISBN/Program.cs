﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CCC_ISBN
{
    class Program
    {
        static void Main(string[] args)
        {
            int answer = 9 * 1 + 7 * 3 + 8 * 1 + 0 * 3 + 9 * 1 + 2 * 3 + 1 * 1 + 4 * 3 + 1 * 1 + 8 * 3;
            int[] input = new int[3];
            for (int i = 0; i < 3; i++)
            {
                input[i] = int.Parse(Console.ReadLine());
            }
            answer += (input[0] + (input[1] * 3) + input[2]);
            Console.WriteLine("The 1-3-sum is " + answer);
            Console.ReadLine();
        }
    }
}
