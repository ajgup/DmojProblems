﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CCC_RSA_numbers
{
    class Program
    {
        static void Main(string[] args)
        {
            int min = int.Parse(Console.ReadLine());
            int max = int.Parse(Console.ReadLine());
            double math1 = 0;
            double math2 = 0;
            int total=0;
            int[] divisors = new int[(max - min) + 1];
            for (int i = min; i < (max-min)+1 + min; i++)
            {
                for (int x = 1; x <= i+1; x++)
                {
                  //  Console.WriteLine(i+ "/" + x);
                    math1 = i;
                    math2 = x;
                    if ((math1/math2) % 1 == 0)
                    {
                       // Console.WriteLine((i / x) + " : " + (i / x) % 2);
                        divisors[i-min]++;
                    }
                }
             //   Console.WriteLine(i + " : " + divisors[i-min]);          
            }
            for (int i = 0; i < divisors.Length; i++)
            {
                if (divisors[i]==4)
                {
                    total++;
                }
            }
            Console.WriteLine("The number of RSA numbers between {0} and {1} is {2}",min,max,total);
            Console.ReadKey();
        }
    }
}
