﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ListMinimum
{
    class Program
    {
        static void Main(string[] args)
        {
            int loop = int.Parse(Console.ReadLine());
            int[] nums = new int[loop];
            for (int i = 0; i < loop; i++)
            {
                nums[i] = int.Parse(Console.ReadLine());
            }
            Array.Sort(nums);
            foreach (var item in nums)
            {
                Console.WriteLine(item);
            }
        }
    }
}
