﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HailstoneNumbers
{
    class Program
    {
        
        static void Main(string[] args)
        {
            int num = int.Parse(Console.ReadLine());
            int counter = 0;
            Console.WriteLine(Test(num, counter));
        }
        public static int Test(int num, int counter)
        {
            
            if (num == 1)
            {
                return counter;
            }
            if (num % 2 == 0)
            {
                counter++;
                return Test(num / 2, counter);
                
            }
            else
            {
                counter++;
                return Test((num * 3) + 1, counter);   
            }
        }
    }
}
