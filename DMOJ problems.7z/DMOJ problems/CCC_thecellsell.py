a = int(input())
b = int(input())
c = int(input())
aa = a-100
ba = a-250
planA = 0
planB = 0

for x in range (aa, 0, -1):
    planA += 0.25

planA += b * 0.15


planA += c * 0.20

for x in range (ba, 0, -1):
    planB += 0.45

for x in range(b):
    planB += 0.35
    
for x in range(c):
    planB += 0.25
    
planA = round(planA,2)
planB = round(planB,2)
print("Plan A costs " + str(planA))
print("Plan B costs " + str(planB))
if planA > planB:
    print("Plan B is cheapest.")
elif planA == planB:
    print("Plan A and B are the same price.")
else:
    print("Plan A is cheapest.")

