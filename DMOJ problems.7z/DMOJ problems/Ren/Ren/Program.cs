﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ren
{
    class Program
    {
        static void Main(string[] args)
        {
            int loop = int.Parse(Console.ReadLine());
            int[] people = new int[loop];
            string answer = "";
            for (int i = 0; i < loop; i++)
            {
                people[i] = int.Parse(Console.ReadLine());
            }
            for (int i = 1; i < loop; i++)
            {
                if (people[0] > people[i])
                {
                    answer = "YES";
                
                }
                else
                {
                    answer = "NO";
                    break;
                }
            }
            Console.WriteLine(answer);
            Console.ReadKey();
        }
    }
}
