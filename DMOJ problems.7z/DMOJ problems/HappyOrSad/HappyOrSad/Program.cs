﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HappyOrSad
{
    class Program
    {
        static void Main(string[] args)
        {
            string text = Console.ReadLine();
            char[] line = text.ToCharArray();
            int happy = 0;
            int sad = 0;
            for (int i = 0; i < text.Length; i++)
            {
                if (line[i] == ':')
                {
                    if (line[i + 1] == '-')
                    {
                        if(line[i + 2] == ')')
                        {
                            happy++;
                        }
                        if (line[i + 2] == '(')
                        {
                            sad++;
                        }
                    }
                }
              
            }
            if (happy == 0 && sad==0)
            {
                Console.WriteLine("none");
            }
            else if (happy == sad)
                {
                    Console.WriteLine("unsure");
                }
            else if(happy > sad)
                {
                    Console.WriteLine("happy");
                }
            else
            {
                Console.WriteLine("sad");
            }
        }
    }
}
