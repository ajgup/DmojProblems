﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CCC_canadian_calorie
{
    class Program
    {
        static void Main(string[] args)
        {
            int total = 0;
            int order = int.Parse(Console.ReadLine());
            int order2 = int.Parse(Console.ReadLine());
            int order3 = int.Parse(Console.ReadLine());
            int order4 = int.Parse(Console.ReadLine());
            if (order == 1)
            {
                total += 461;
            }
            else if (order == 2)
            {
                total += 431;
            }
            else if (order == 3)
            {
                total += 420;
            }
 
            if (order2 == 1)
            {
                total += 100;
            }
            else if (order2 == 2)
            {
                total += 57;
            }
            else if (order2 == 3)
            {
                total += 70;
            }

            if (order3 == 1)
            {
                total += 130;
            }
            else if (order3 == 2)
            {
                total += 160;
            }
            else if (order3 == 3)
            {
                total += 118;
            }

            if (order4 == 1)
            {
                total += 167;
            }
            else if (order4 == 2)
            {
                total += 266;
            }
            else if (order4 == 3)
            {
                total += 75;
            }
            Console.WriteLine("Your total Calorie count is " + total + ".");
        }
    }
}
