﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MockingSpongebobDmoj
{
    class Program
    {
        static void Main(string[] args)
        {
            int num = int.Parse(Console.ReadLine());
            List<string> words = new List<string>();
            string outp = "";
            List<string> output = new List<string>();
            bool lower = true;
            for (int i = 0; i < num; i++)
            {
                words.Add(Console.ReadLine());
                foreach (char c in words[i])
                {
                    char temp = c;
                    if (int.TryParse(c.ToString(), out int numtest))
                    {
                        outp += numtest;
                        continue;
                    }
                    if ((System.Convert.ToInt32(temp) <97 && temp > 90 )|| temp >122 || temp < 65)
                    {
                        outp += temp;
                        continue;
                    }
                    if (lower)
                    {
                        outp += c.ToString().ToLower();
                        lower = false;
                    }
                    else
                    {
                        outp += c.ToString().ToUpper();
                        lower = true;
                    }
                }
                output.Add(outp);
                outp = "";
                lower = true;
                Console.WriteLine(output[i]);
            }
            Console.ReadLine();
           
        }
    }
}
