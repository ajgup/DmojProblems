﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LucasOtherTower
{
    class Program
    {
        static void Main(string[] args)
        {
            for (int i = 0; i < 10; i++)
            {
                string[] test = Console.ReadLine().Split();
                int input = int.Parse(test[0]);
                double answer = input + (input-1);
                Console.WriteLine(answer);
            }
        }
    }
}
