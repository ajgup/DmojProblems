﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace P5
{
    class Program
    {
        static void Main(string[] args)
        {
            string[] line = Console.ReadLine().Split();
            int[] num = new int[line.Length];
            int length = 0;
            int friends = 0;
       

            for (int i = 0; i < line.Length; i++)
            {
                num[i] = int.Parse(line[i]);
            }
            length = num[0];
            friends = num[1];

            List<string> letter = new List<string>();
            List<int> numOfTimes = new List<int>();
            List<int> withinLetter = new List<int>();

            for (int i = 0; i < friends; i++)
            {
                string[] tempFriend = Console.ReadLine().Split();
                letter.Add(tempFriend[0]);
                numOfTimes.Add(int.Parse(tempFriend[1]));
                withinLetter.Add(int.Parse(tempFriend[1]));
            } 
        }
    }
}
