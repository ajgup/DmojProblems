﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Problem2
{
    class Program
    {
        static void Main(string[] args)
        {
            double numgroup = int.Parse(Console.ReadLine());
            double evil = 0;
            double total = 0;
            double PGroup = 0;
            double PTotal = 0;
            for (int i = 0; i < numgroup; i++)
            {
                string Line = Console.ReadLine();
                string[] numbers = Line.Split();
                evil = double.Parse(numbers[0]);
                total = double.Parse(numbers[1]);
                PGroup = (evil / total);
                PGroup = 1 - PGroup;
                if (i == 0)
                {
                    PTotal = PGroup;                   
                }
                else
                {
                    PTotal = PTotal * PGroup;          
                }
            }
  
            Console.WriteLine(PTotal);
            Console.ReadLine(); 
        }
    }
}
