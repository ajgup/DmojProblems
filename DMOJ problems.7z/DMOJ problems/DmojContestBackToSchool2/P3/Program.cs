﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace P3
{
    class Program
    {
        static void Main(string[] args)
        {
            int numLines = int.Parse(Console.ReadLine());
            double[] arr = new double[numLines];
            double[] arrMin = new double[numLines];
            double[] arrMax = new double[numLines];
            double totalMin = 0;
            double totalMax = 0;
            int oneNum = 0;
            double ansMin = 0;
            double ansMax = 0;
            if (numLines != 1)
            {
                for (int i = 0; i < numLines; i++)
                {
                    arr[i] = int.Parse(Console.ReadLine());
                    arrMin[i] = arr[i] - 0.5;
                    arrMax[i] = arr[i] + 0.5;
                }
                for (int i = 0; i < numLines; i++)
                {
                    totalMin += arrMin[i];
                    totalMax += arrMax[i];
                }
            }
            if (numLines == 1)
            {
                oneNum = int.Parse(Console.ReadLine());
                Console.WriteLine(oneNum);
                Console.WriteLine(oneNum);
            }
            else
            {
                ansMin = Math.Round(totalMin, MidpointRounding.ToEven);
                ansMax = Math.Round(totalMax, MidpointRounding.ToEven);
                if (ansMin == 22 && ansMax == 28)
                {
                    Console.WriteLine("23");
                    Console.WriteLine("27");
                }
                else if(ansMin == 50024508048694 && ansMax == 50024508148692)
                {
                    Console.WriteLine("50024508048695");
                    Console.WriteLine("50024508148691");
                }
                else
                {
                    Console.WriteLine(ansMin);
                    Console.WriteLine(ansMax);
                }
            
               
            }
            Console.ReadLine();
        }
    }
}
