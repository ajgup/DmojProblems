﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DmojContestBackToSchool2
{
    class Program
    {
        static void Main(string[] args)
        {
            string line = Console.ReadLine();
            string[] arr = line.Split();
            char first;
            string answer = "";
            int num = arr.Length;
            for (int i = 1; i < arr.Length; i++)
            {
                first = char.Parse(arr[i].Substring(0, 1));

                if (char.IsUpper(first))
                {
                    arr[i - 1] += ".";
                    
                }
                if (i != arr.Length)
                {
                    answer += arr[i - 1] + " ";

                }
               
            }
            answer += arr[num-1]+".";
            Console.WriteLine(answer);
            Console.ReadLine();
        }
    }
}
