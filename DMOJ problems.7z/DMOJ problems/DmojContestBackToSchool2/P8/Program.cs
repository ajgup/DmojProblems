﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace P8
{
    class Program
    {
        static void Main(string[] args)
        {
            int commands = int.Parse(Console.ReadLine());
            string[] line = new string[commands];
            string input = Console.ReadLine();
            string answer = "0";
            int[] nums = new int[commands];
            long ans = 0;
            string final = "";
            for (int i = 0; i < commands; i++)
            {
                line[i] = input.Substring(i, 1);
            }
            for (int i = 0; i < commands; i++)
            {
                if (line[i] != "-")
                {
                    answer += line[i];
                }
                else
                {
                    answer = answer.Substring(0,answer.Length-1);
                }

               // Console.WriteLine(answer);
                nums[i] = int.Parse(answer);
                ans += nums[i];
                final = ans.ToString();
            }
            
            Console.WriteLine(final);
            Console.ReadLine();
        }
    }
}
