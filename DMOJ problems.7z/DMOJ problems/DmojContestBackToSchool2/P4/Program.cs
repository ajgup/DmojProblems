﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace P4
{
    class Program
    {
        static void Main(string[] args)
        {
            string[] line = Console.ReadLine().Split();
            int[] nums = new int[line.Length];
            int[] tempLines = new int[2];
            for (int i = 0; i < line.Length; i++)
            {
                nums[i] = int.Parse(line[i]);
            }
            List<int> mud = new List<int>();
            for (int i = 0; i < (nums[1] * 2); i++)
            {
                string[] temp = Console.ReadLine().Split();
                tempLines[0] = int.Parse(temp[0]);
                tempLines[1] = int.Parse(temp[1]);
                mud.Add(tempLines[0]);
                mud.Add(tempLines[1]);
            }
        }
    }   
}
