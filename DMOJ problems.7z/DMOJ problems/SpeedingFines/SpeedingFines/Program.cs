﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SpeedingFines
{
    class Program
    {
        static void Main(string[] args)
        {
            int limit;
            int speed;
        
                limit = int.Parse(Console.ReadLine());
                speed = int.Parse(Console.ReadLine());
            
            if (speed >= limit+1 && speed <= limit+20)
            {
                Console.WriteLine("You are speeding and your fine is $100.");
            }
            else if (speed >= limit + 21 && speed <= limit + 30)
            {
                Console.WriteLine("You are speeding and your fine is $270.");
            }
            else if (speed > limit + 30)
            {
                Console.WriteLine("You are speeding and your fine is $500.");
            }
            else
            {
                Console.WriteLine("Congratulations, you are within the speed limit!");
            }
          
          
        }
    }
}
