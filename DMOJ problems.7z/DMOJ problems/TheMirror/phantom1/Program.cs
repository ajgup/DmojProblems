﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace phantom1
{
    class Program
    {
        static void Main(string[] args)
        {
            int loop = int.Parse(Console.ReadLine());
            for (int k = 0; k < loop; k++)
            {
                string[] inp = Console.ReadLine().Split();
                int low = int.Parse(inp[0]);
                int high = int.Parse(inp[1]);
                int count = 0;

                for (int i = low; i < high; i++)
                {
                    int divisors = 0;
                    for (int j = 1; j <= i; j++)
                    {
                        if (i % j == 0)
                        {
                            divisors++;
                        }
                    }
                    if (divisors == 2)
                    {
                        count++;
                    }
                }
                Console.WriteLine(count);
            }
            Console.ReadLine();
        }
    }
}
