﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Squares
{
    class Program
    {
        static void Main(string[] args)
        {
            int tiles = int.Parse(Console.ReadLine());
            Console.WriteLine("The largest square has side length " + Math.Floor( Math.Sqrt(tiles))+".");
            Console.ReadKey();
        }
    }
}
