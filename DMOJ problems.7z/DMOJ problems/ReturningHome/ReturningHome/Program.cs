﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ReturningHome
{
    class Program
    {
        static void Main(string[] args)
        {
            List<string> instruct = new List<string>();
            List<string> direct = new List<string>();
            List<string> places = new List<string>();
            string inp = "";
            do
            {
                inp = Console.ReadLine();
                instruct.Add(inp);
            } while (inp != "SCHOOL");
            instruct.Reverse();
            instruct.Remove("SCHOOL");
            for (int i = 0; i < instruct.Count; i++)
            {
                if (instruct[i] == "R")
                {
                    direct.Add("LEFT");
                }
                else if (instruct[i] == "L")
                {
                    direct.Add("RIGHT");
                }
                else
                {
                    places.Add(instruct[i]);
                }
            }
            //last instruction must be home so dont read final direction
            for (int i = 0; i < direct.Count -1; i++)
            {
                Console.WriteLine("Turn {0} onto {1} street.", direct[i], places[i]);
            }
            Console.WriteLine("Turn {0} into your HOME.", direct[direct.Count-1]);
            Console.ReadLine();
        }
    }
}
