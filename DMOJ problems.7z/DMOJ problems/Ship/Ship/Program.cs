﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ship
{
    class Program
    {
        static void Main(string[] args)
        {
            string ship = Console.ReadLine();
            if (ship.Contains("B") == false)
            {
                Console.WriteLine("B");
            }
             if (ship.Contains("F") == false)
            {
                Console.WriteLine("F");
            }
             if (ship.Contains("T") == false)
            {
                Console.WriteLine("T");
            }
             if (ship.Contains("L") == false)
            {
                Console.WriteLine("L");
            }
             if (ship.Contains("C") == false)
            {
                Console.WriteLine("C");
            }
            if(ship.Contains("B") && ship.Contains("F") && ship.Contains("T") && ship.Contains("L") && ship.Contains("C"))
            {
                Console.WriteLine("NO MISSING PARTS");
            }
        }
    }
}
