﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NextInLine
{
    class Program
    {
        static void Main(string[] args)
        {
            int age1 = int.Parse(Console.ReadLine());
            int age2 = int.Parse(Console.ReadLine());
            Console.WriteLine(age2 + (age2 - age1));
            Console.ReadKey();
        }
    }
}
