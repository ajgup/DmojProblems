﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace IconScaling
{
    class Program
    {
        static void Main(string[] args)
        {
            int size = int.Parse(Console.ReadLine());
            string final = "";
            for (int i = 0; i < size; i++)
            {
                for (int x = 0; x < size; x++)
                {
                    final += ("*");
                }
                for (int x = 0; x < size; x++)
                {
                    final += ("x");
                }
                for (int x = 0; x < size; x++)
                {
                    final += ("*");
                }
                final += "\n";
            }

            for (int i = 0; i < size; i++)
            {
                for (int x = 0; x < size; x++)
                {
                    final += (" ");
                }
                for (int x = 0; x < size; x++)
                {
                    final += ("xx");
                }
                final += "\n";
            }
            for (int i = 0; i < size; i++)
            {
                for (int x = 0; x < size; x++)
                {
                    final += ("*");
                }
                for (int x = 0; x < size; x++)
                {
                    final += (" ");
                }
                for (int x = 0; x < size; x++)
                {
                    final += ("*");
                }
                final += "\n";
            }
            Console.WriteLine(final);
            Console.ReadKey();
        }
    }
}
