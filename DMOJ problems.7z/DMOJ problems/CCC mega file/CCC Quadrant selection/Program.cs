﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CCC_Quadrant_selection
{
    class Program
    {
        static void Main(string[] args)
        {
            int x = int.Parse(Console.ReadLine());
            int y = int.Parse(Console.ReadLine());
            if (x > 0)
            {
                if (y>0)
                {
                    Console.WriteLine("1");
                }
                if (y<0)
                {
                    Console.WriteLine("4");
                }
            }
            if (x<0)
            {
                if (y > 0)
                {
                    Console.WriteLine("2");
                }
                if (y < 0)
                {
                    Console.WriteLine("3");
                }
            }
        }
    }
}
