﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CCC_multiple_choice
{
    class Program
    {
        static void Main(string[] args)
        {
            int size = int.Parse(Console.ReadLine());
            string[] student = new string[size];
            string[] answers = new string[size];
            int correct = 0;
            for (int i = 0; i < size; i++)
            {
                student[i] = Console.ReadLine();
            }
            for (int i = 0; i < size; i++)
            {
                answers[i] = Console.ReadLine();
            }
            for (int i = 0; i < size; i++)
            {
                if (student[i] ==  answers[i])
                {
                    correct++;
                }
            }
            Console.WriteLine(correct);
        }
    }
}
