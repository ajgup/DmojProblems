﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
/*Ajay Gupta
 *December 2016
 * DiceGame
 * User plays with dice */
namespace DiceGame
{
    class Program
    {
        static void Main(string[] args)
        {
            int rounds = int.Parse(Console.ReadLine());
            int AntoniaPoints = 100;
            int DavidPoints = 100;

            int AntoniaDice = 0;
            int DavidDice = 0;
            string input = "";
            for (int i = 0; i < rounds; i++)
            {
                input = Console.ReadLine();
                AntoniaDice = int.Parse(input.Substring(0,1));
                DavidDice = int.Parse(input.Substring(1).Trim());
                if (AntoniaDice > DavidDice)
                {
                    DavidPoints = DavidPoints - AntoniaDice;
                }
                else if (AntoniaDice < DavidDice)
                {
                    AntoniaPoints = AntoniaPoints - DavidDice;
                }
            }
            Console.WriteLine(AntoniaPoints);
            Console.WriteLine(DavidPoints);
            Console.ReadKey();
        }
    }
}