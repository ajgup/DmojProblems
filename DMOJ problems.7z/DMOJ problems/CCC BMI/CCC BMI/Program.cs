﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CCC_BMI
{
    class Program
    {
        static void Main(string[] args)
        {
            double weight = double.Parse(Console.ReadLine());
            double height = double.Parse(Console.ReadLine());
            double bmi = weight / (height * height);

            if (bmi>25)
            {
                Console.WriteLine("Overweight");
            }
            else if (bmi >= 18.5 && bmi <= 25.0)
            {
                Console.WriteLine("Normal weight");
            }
            else if (bmi < 18.5)
            {
                Console.WriteLine("Underweight");
            }

            Console.ReadKey();
        }
    }
}
