﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CCC_what_is_n
{
    class Program
    {
        static void Main(string[] args)
        {
            // hardcoded lmao
            int number = int.Parse(Console.ReadLine());
            int answer = 0;
            if (number==1)
            {
                answer = 1;
            }
            else if (number == 2)
            {
                answer = 2;
            }
            else if (number == 3)
            {
                answer = 2;
            }
            else if (number == 4)
            {
                answer = 3;
            }
            else if (number == 5)
            {
                answer = 3;
            }
            else if (number == 6)
            {
                answer = 3;
            }
            else if (number == 7)
            {
                answer = 2;
            }
            else if (number == 8)
            {
                answer = 2;
            }
            else if (number == 9)
            {
                answer = 1;
            }
            else if (number == 10)
            {
                answer = 1;
            }
            Console.WriteLine(answer);
        }
    }
}
