﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CCC_whos_in_the_middle
{
    class Program
    {
        static void Main(string[] args)
        {
            int[] weights = new int[3];
            for (int i = 0; i < 3; i++)
            {
                weights[i] = int.Parse(Console.ReadLine());
            }
            Array.Sort(weights);
            Console.WriteLine(weights[1]);
            Console.ReadKey();
        }
    }
}
