﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CCC_rock_paper_scissors
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.ReadLine();
            string[] alice = Console.ReadLine().Split(' ');
            string[] bob = Console.ReadLine().Split(' ');
            int[] score = new int[2]; //0 is alice, 1 is bob
            string answer = "";
            for (int i = 0; i < alice.Length; i++)
            {
                if (alice[i] == "paper" && bob[i] == "rock")
                {
                    score[0]++;
                }
                else if(alice[i] == "rock" && bob[i] == "scissors")
                {
                    score[0]++;
                }
                else if (alice[i] == "scissors" && bob[i] == "paper")
                {
                    score[0]++;
                }
                if (bob[i] == "paper" && alice[i] == "rock")
                {
                    score[1]++;
                }
                else if (bob[i] == "rock" && alice[i] == "scissors")
                {
                    score[1]++;
                }
                else if (bob[i] == "scissors" && alice[i] == "paper")
                {
                    score[1]++;
                }
            }
            answer = score[0] + " " + score[1];
            Console.WriteLine(answer);
        }
    }
}
