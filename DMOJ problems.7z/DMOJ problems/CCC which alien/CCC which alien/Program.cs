﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CCC_which_alien
{
    class Program
    {
        static void Main(string[] args)
        {
            int ant = int.Parse(Console.ReadLine());
            int eye = int.Parse(Console.ReadLine());
            if (ant >= 3 && eye <= 4)
            {
                Console.WriteLine("TroyMartian");
            }
            if (ant <= 6 && eye >= 2)
            {
                Console.WriteLine("VladSaturnian");
            }
            if (ant <= 2 && eye <= 3)
            {
                Console.WriteLine("GraemeMercurian");
            }
            Console.ReadKey();
        }
    }
}
