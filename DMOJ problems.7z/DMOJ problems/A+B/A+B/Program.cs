﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace A_B
{
    class Program
    {
        static void Main(string[] args)
        {
            int Loop = int.Parse(Console.ReadLine());
            int[] add = new int[2];
            for (int i = 0; i < Loop; i++)
            {
                string[] numbers =  Console.ReadLine().Split();
                add[0] = int.Parse(numbers[0]);
                add[1] = int.Parse(numbers[1]);
                Console.WriteLine(add[0] + add[1]);
            }
        }
    }
}
